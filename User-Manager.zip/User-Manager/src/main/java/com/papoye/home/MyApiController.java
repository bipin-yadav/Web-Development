package com.papoye.home;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyApiController {

	@RequestMapping(value = "/getUser", method = RequestMethod.GET ,produces="application/json" )	
	public @ResponseBody JSONObject getAllUser()   {				 			 
		System.out.println("in getUser method.");
		JSONObject jobj = new NormalDbCOnnection().getAllUserDetails();			
		return jobj;
	}
	
	@RequestMapping(value = "/createUser", method = RequestMethod.POST ,produces="application/json" )	
	public @ResponseBody JSONObject createUser(@RequestBody UserBean ub)   {	
		System.out.println(ub.getEmail());
		System.out.println("in createUser method.");
		JSONObject jobj = new JSONObject();
		int i = new NormalDbCOnnection().createUser(ub);
		if(i > 0 ){
			jobj.put("msg", "user created");	
		} else {
			jobj.put("msg", "user not created");
		}
		return jobj;
	}
	
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST ,produces="application/json" )	
	public @ResponseBody JSONObject updateUser(@RequestBody UserBean ub)   {	
		System.out.println(ub.getEmail());
		System.out.println("in updateUser method.");
		JSONObject jobj = new JSONObject();
		int i = new NormalDbCOnnection().updateUser(ub);
		if(i > 0 ){
			jobj.put("msg", "user updated");	
		} else {
			jobj.put("msg", "user not updated");
		}
		return jobj;
	}
	
	@RequestMapping(value = "/delUser", method = RequestMethod.GET ,produces="application/json" )	
	public @ResponseBody void delUser(@RequestParam("id") String id) {				 			 
		System.out.println("in deluser method.");
		int jobj = new NormalDbCOnnection().deleteUser(id);			
		return;
	}
	
	@RequestMapping(value = "/status", method = RequestMethod.GET ,produces="application/json" )	
	public @ResponseBody JSONObject status(@RequestParam("status") String status,@RequestParam("id") String id) {				 			 
		System.out.println("in status method.");
		JSONObject jobj = new JSONObject();
		int i = new NormalDbCOnnection().updateUserStatus(id, status);
		if(i > 0 ){
			jobj.put("msg", "user updated");	
		} else {
			jobj.put("msg", "user not updated");
		}
		return jobj;
	}
	
}
