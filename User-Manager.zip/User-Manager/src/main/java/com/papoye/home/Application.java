package com.papoye.home;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * MyApiController class for all Rest-API services.
 *
 * @author      Bipin Yadav
 * @version     0.1
 * @see
 */
@SpringBootApplication
public class Application {

	/** 
     * Convert process method
     *
     * By url /post json object send to company, having the same structure.
	 * By @ResponseBody returning the json to angular.
	 * By @RequestBosy  accepting the json object.
     * @param 			convert    
     * @return          true if all conversion process completed successfully. 
     *               	false if any type of error or exception occurred during
     *               	the conversion process.
     * @see             MyViewController
     * @version         0.1
     */	
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
