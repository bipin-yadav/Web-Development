package com.papoye.home;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class NormalDbCOnnection {
	
	Statement statement;
	ResultSet resultSet;
	String query = "";
	String outResult = "";

	public Connection cretaeConnection() {
		Connection connection = null;
		String dbUrl = "jdbc:mysql://localhost:3306/dbsearch";
		String dbClass = "com.mysql.jdbc.Driver";
		String username = "root";
		String password = "root";
		try {
			Class.forName(dbClass);
			connection = DriverManager.getConnection(dbUrl, username, password);
			System.out.println(dbUrl);
			System.out.println("Connection created " + connection);
		} catch (Exception e) {
			System.out.println("Exception in Create Connection");
			e.printStackTrace();
		}
		return connection;
	}

	public JSONObject getAllUserDetails() {
			String sql = "select * from dbsearch.user";
			Connection connection = cretaeConnection();	
			JSONObject jobj=null;
			JSONArray jarry = new JSONArray();
			JSONObject fjobj = new JSONObject();
			try {
				statement = connection.createStatement();
				resultSet = statement.executeQuery(sql);
				System.out.println("re" + resultSet);				
				while (resultSet.next()) {
					jobj = new JSONObject();
					jobj.put("id", resultSet.getInt(1));
					jobj.put("firstName", resultSet.getString(2));
					jobj.put("lastName", resultSet.getString(3));
					jobj.put("userid", resultSet.getString(4));
					jobj.put("email", resultSet.getString(5));
					jobj.put("status", resultSet.getString(6));
					jobj.put("city", resultSet.getString(7));
					jarry.add(jobj);
				}	
				fjobj.put("users", jarry);
			} catch (SQLException sqle) {
				sqle.printStackTrace();
				} finally {
				if (connection != null) {
					try {
						connection.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		return fjobj;
	}
	
	
	public int createUser(UserBean ub) {
		int i = 0;
		Connection connection = cretaeConnection();
		 
		String query = "insert into dbsearch.user (FIRST_NAME,lAST_NAME,USER_ID,EMAIL_ID,STATUS,CITY,id) values(?,?,?,?,?,?,?);";
		PreparedStatement pst;
		try {			
			System.out.println("********>>" + query + "<<*****");
			pst = connection.prepareStatement(query);
			pst.setString(1, ub.getFirstName());
			pst.setString(2, ub.getLastName());
			pst.setString(3, ub.getUserid());
			pst.setString(4, ub.getEmail());
			pst.setString(5, ub.getStatus());
			pst.setString(6, ub.getCity());	
			pst.setInt(7, ub.getId());
			try {
				i = pst.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}					
		return i;
	}
	
	public int deleteUser(String id) {
		int i = 0;
		Connection connection = cretaeConnection();
		String query = "delete from dbsearch.user where id="+id;
		PreparedStatement pst;
		try {			
			System.out.println("********>>" + query + "<<*****");
			pst = connection.prepareStatement(query);	
			try {
				i = pst.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}					
		return i;		
	}

	public int updateUser(UserBean ub) {
		System.out.println(ub.getCity());
		int i = 0;
		Connection connection = cretaeConnection();
		String query = "update dbsearch.user set"+" FIRST_NAME='"+ub.getFirstName()+"',lAST_NAME='"+ub.getLastName()+"',USER_ID='"+ub.getUserid()+"',EMAIL_ID='"+ub.getEmail()+"',CITY='"+ub.getCity()+"' where id="+ub.getId();
		PreparedStatement pst;
		try {			
			System.out.println("********>>" + query + "<<*****");
			pst = connection.prepareStatement(query);	
			try {
				i = pst.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}					
		return i;		
	}
	
	public int updateUserStatus(String id, String status) {
		System.out.println(status);
		int i = 0;
		Connection connection = cretaeConnection();
		String query = "update dbsearch.user set STATUS='"+status+"'  where id="+id;
		PreparedStatement pst;
		try {			
			System.out.println("********>>" + query + "<<*****");
			pst = connection.prepareStatement(query);	
			try {
				i = pst.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}					
		return i;		
	}
	
}
