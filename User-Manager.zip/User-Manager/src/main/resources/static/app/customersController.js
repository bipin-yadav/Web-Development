app.controller('CustomersController', function( $scope, $http, $route,$location,$window, customerService ){
    console.log("inside CustomersController");
    $scope.newCustomer={};
    $scope.save=true;
    $scope.newCustomer.id = '';
    $scope.newCustomer.firstName = '';
    $scope.newCustomer.lastName = '';
    $scope.newCustomer.city = '';
    $scope.newCustomer.email = '';
    $scope.newCustomer.userid = '';
    
    $scope.customers = customerService.getAllCustomers();
    
    $scope.show =  function(){
    	console.log("in save");
    	return $scope.save;
    }
    
    $scope.insertCustomer = function () {
        var firstName = $scope.newCustomer.firstName;
        var lastName = $scope.newCustomer.lastName;
        var city = $scope.newCustomer.city;
        var email = $scope.newCustomer.email;
        var userid = $scope.newCustomer.userid;
        customerService.insertCustomer(firstName, lastName, city, email, userid);
        
        $scope.newCustomer.firstName = '';
        $scope.newCustomer.lastName = '';
        $scope.newCustomer.city = '';
        $scope.newCustomer.email = '';
        $scope.newCustomer.userid = '';
        
    };

    $scope.deleteCustomer = function (id) {
    	$http({
	        method : "GET",
	        url : "/delUser?id="+id
	    }).then(function mySucces(response) {	         
	        console.log(response);	        
	    }, function myError(response) {
	    	console.log(response);
	    });
        customerService.deleteCustomer(id);       
    };
    
    $scope.enableCustomer = function (id) {
    	 console.log(id);
    };
    
    $scope.disableCustomer = function (id) {
    	 console.log(id);
    };
    
    $scope.editCustomer = function (id) {
        var customer = customerService.getCustomer(id);
        console.log(customer);
        $scope.save=false;
        $scope.newCustomer.id = id;
        $scope.newCustomer.firstName = customer.firstName;
        $scope.newCustomer.lastName = customer.lastName;
        $scope.newCustomer.city = customer.city;
        $scope.newCustomer.email = customer.email;
        $scope.newCustomer.userid = customer.userid;
        //update(id,customer.firstName, customer.lastName, customer.city, customer.email, customer.userid);
        
    };
    
    $scope.updateCustomer = function () {
    	 console.log( $scope.newCustomer.firstName);
    	 console.log( $scope.newCustomer.id);
    	 var user = {
    			 firstName : $scope.newCustomer.firstName,
    	 		 lastName : $scope.newCustomer.lastName,
    	 		 city:$scope.newCustomer.city,
    	 		 email:$scope.newCustomer.email,
    	 		 userid:$scope.newCustomer.userid,
    	 		 id: $scope.newCustomer.id
    	 }
    	 $http.post('/updateUser', user)
         .success(function (response) {
       	  console.log(response.data);
         })
         .error(function (response) {
       	  console.log(response.data);
         });	
    	// $location.path("/user");
    	 $window.location.reload();
    }
    
});
