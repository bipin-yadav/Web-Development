var app = angular.module('userApp', ['ngRoute']);

//This configures the routes and associates each route with a view and a controller
app.config(function ($routeProvider, $locationProvider) {
  
    $routeProvider
        .when('/users',
            {
                controller: 'CustomersController',
                templateUrl: 'views/customers-tmpl.html'
            })
     
        .otherwise({ redirectTo: '/users' });
});


app.controller('EditCtl', function( $scope, $http, customerService)  {
	  
		
		
});
