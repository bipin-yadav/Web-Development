app.service('customerService', function($http){
	console.log('inside customerService ');
	var customers = [];
	this.getAllCustomers = function(){
		customers = [];
		$http({
	        method : "GET",
	        url : "/getUser"
	    }).then(function mySucces(response) {	         
	        console.log(response.data.users);
	        for (var i = 0; i < response.data.users.length; i++) {
	            console.log(response.data.users[i]);
	            customers.push({
	                id: response.data.users[i].id,
	                firstName: response.data.users[i].firstName,
	                lastName: response.data.users[i].lastName,
	                city: response.data.users[i].city,
	                email: response.data.users[i].email,
	                userid: response.data.users[i].userid,
	                status: response.data.users[i].status
	            });
	        }
	    }, function myError(response) {
	    	console.log(response.data);
	    });
		
		return customers;
	};

  this.insertCustomer = function (firstName, lastName, city, email, userid) {
	  var topID = customers.length + 1;
	  var user = {
			  		id : topID,
				  	firstName: firstName,
		            lastName: lastName,
		            city: city,
		            email: email,
		            userid: userid,
		            status: "enable"
	  			};
	  console.log(JSON.stringify(user));
	  $http.post('/createUser', user)
      .success(function (response) {
    	  console.log(response.data);
    	  customers.push({
              id: topID,
              firstName: firstName,
              lastName: lastName,
              city: city,
              email: email,
              userid: userid,
              status: "enable"
          });
      })
      .error(function (response) {
    	  console.log(response.data);
      });	  
    };

    this.deleteCustomer = function (id) {
         console.log(id);
         for (var i = customers.length - 1; i >= 0; i--) {
             if (customers[i].id === id) {
                 customers.splice(i, 1);// to remove object
                 break;
             }
         }
    };
    
    this.editCustomer = function (id,firstName, lastName, city, email, userid) {
        console.log("in service"+id);
        
   };

    this.getCustomer = function (id) {
        for (var i = 0; i < customers.length; i++) {
            if (customers[i].id === id) {
                return customers[i];
            }
        }
        return null;
    };

});